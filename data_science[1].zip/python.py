def compare_to_five(x):
    if x < 6:
        return"goatz love"
    elif x > 14:
        return"gotaz love"

print (compare_to_five(11))